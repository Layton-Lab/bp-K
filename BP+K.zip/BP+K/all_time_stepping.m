% This subroutine advances the system of model equations in time. 
% specifically, it sets up the parameters and calls ode15s

% Required input parameters:
% human - 1 to run a human simulation, 0 for the rat simulation
% gg - 1 for male, 2 for female
% IG - string containing the filename of the initial guess for the solver

% Optional input parameters: (each should be a string followed by a value)
% 'ACEi', # - 0 for no treatment, 1 for normal dose, 2 for high dose. Default is 0.
% 'furosemide', # - 0 for no treatment, 1 for normal dose, 2 for high dose. Default is 0.
% 'NSAID', # - 0 for no treatment 1 for normal dose, 2 for high dose. Default is 0.
% 'Impaired Myogenic Response', # - 0 for normal, 1 for impaired. Default is 0.
% 'Low Water Intake', # - 0 for normal, 1 for low water intake. Default is 0.
% 'RSNA', # - value by which N_rsna is multiplied by to induce hypertension. In my simulations it is 1 for normotensive simulations, 2.5 for hypertensive. Default is 1.

function [isimag,t,x] = all_time_stepping(human,gg,IG)

    species = {'rat','human'};
    gender     = {'male', 'female'};
    sex = gg-1;
    
    %% Define default imputs for blood pressure model
    AA = 1;
    ACEi = 0;
    furosemide = 0;
    NSAID = 0;
    myo_ind = 0;
    water_ind = 0;
    %% default inputs for K model
    do_figs    = false;
    do_insulin = true;
    do_FF      = true;
    MKX        = 0; MKXslope = 0;
    alt_sim    = false; % use alternate equations

    %% Drug Treatments
    kappa_ACEi = 0;
    kappa_f = 0;
    kappa_f_md = 0;
    
    if ACEi == 1
        kappa_ACEi = 0.76;
    elseif ACEi > 1
        kappa_ACEi = 0.90;
    end
    if furosemide == 1
        kappa_f = 0.15;
        kappa_f_md = 0.4;
    elseif furosemide ==2
        kappa_f = 0.3;
        kappa_f_md = 0.5;
    end 

    %% Parameters
    % A small number of these parameters will be replaced by variables computed in the K model
    %    this will be done in all_eqns, which calls the BP and K models
    pars_BP = get_pars(species{human+1},gender{gg},'RSNA',AA);

    scale_Kin = 1;
    params_K = set_params(sex,scale_Kin);
    [pars_K, parnames] = pars2vector(params_K,0);

    %% set initial conditions
    % BP
    SS_data_struct = load(IG,'SSdata');
    SS_data_IG = SS_data_struct.SSdata;

    if length(SS_data_IG) == 83
        SS_data_IG(84) = 0.126;  % water intake
    end
    x0_BP = SS_data_IG; t = 0;

    % K
    if sex == 0 % male
        temp = load('./SS/SS_5vars_male.mat');
    elseif sex == 1 % female
        temp = load('./SS/SS_5vars_female.mat');
    end
    x0_K = temp.SS;

    % combine
    x0 = [x0_BP x0_K];

    %% Time-step model solution
    tchange=0;
    tspan = [0:1000];
    % 
    M = zeros(length(x0));
    ind = [29 35 46 48 50 51 56 62 65 67 68 69 70 71 72];
    for i=1:length(ind)
        M(ind,ind) = 1; 
    end
    % now fill in extra entries
    M(46,44) = -3/4;  % a_baro, a_auto
    M(50,34) = -0.2;
    %
    options = odeset('Mass',M,'RelTol',1e-4,'AbsTol',1e-6*ones(1,length(x0)));
    all_eqns(t,x0,pars_BP,pars_K,sex,tchange,...
                                            'ACEi',kappa_ACEi,'furosemide',[kappa_f,kappa_f_md],'NSAID',NSAID',...
                                            'Impaired Myogenic Response',myo_ind,'Low Water Intake',water_ind, ...
                                            'SS', true, 'alt_sim', alt_sim,...
                                            'do_MKX', [MKX, MKXslope],...
                                            'do_insulin', do_insulin,...
                                            'do_FF', do_FF);
    %
    [t,x] = ode15s(@(t,x) all_eqns(t,x,pars_BP,pars_K,sex,tchange,...
                                            'ACEi',kappa_ACEi,'furosemide',[kappa_f,kappa_f_md],'NSAID',NSAID',...
                                            'Impaired Myogenic Response',myo_ind,'Low Water Intake',water_ind, ...
                                            'SS', true, 'alt_sim', alt_sim,...
                                            'do_MKX', [MKX, MKXslope],...
                                            'do_insulin', do_insulin,...
                                            'do_FF', do_FF), ...
                            tspan,x0, options);
    y=x(end,:);

    % %Check for imaginary solution.
    if not (isreal(y))
        %disp('Imaginary number returned.')
        isimag = 1;
    else
        isimag = 0;
    end

    % Set any values that are within machine precision of 0 equal to 0.
    for i = 1:length(y)
        if abs(y(i)) < eps*100
            y(i) = 0;
        end
    end

% save_name_ending = '';
% if water_ind
%     save_name_ending = strcat(save_name_ending,'_lowwaterintake');
% end
% if myo_ind
%     save_name_ending = strcat(save_name_ending,'_impairedmyo');
% end


% save_data_name = sprintf('%s_%s_ss_%s_%s_%s_rsna%s%s.mat', species{human+1},gender{gg},num2str(ACEi),num2str(furosemide),num2str(NSAID),num2str(AA),save_name_ending);
% save_data_name = strcat('Human_Data/', save_data_name);
% save(save_data_name, 'SSdata', 'residual', 'exitflag', 'output'


end






























