% High salt / High K, K adaptations results
% All, none, K only, PT only, DT only; M and F
close all

% MAP results
map_m  = [112.9563	132.9422	119.4547	116.4227	118.5345];
gfr_m  = [0.0987	0.1494	0.1307	0.1153	0.1253];
CK_m   = [4.3327	7.4779	3.7540	8.5606	8.5499];

map_f  = [110.5195	123.6051	113.8550	123.6204	111.4615];
gfr_f  = [0.0738	0.1358	0.1001	0.1359	0.0811];
CK_f   = [4.1743	5.9793	3.5409	5.9845	7.1251];

% MAP results
figure(1)
map_data = [map_m; map_f];
% colormap(gray)
bar(map_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'Male', 'Female'})
legend('All','None','K only','PT Na only','DT Na only','Location','southeast')
ylabel('MAP (mmHg)','Fontsize',24)
ti = get(gca,'TightInset');
% ylim([100 150]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,0.95*yl(2),'A','Fontsize',28)

% GFR results
figure(2)
gfr_data = [gfr_m; gfr_f];
% colormap(gray)
bar(gfr_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'Male', 'Female'})
legend('All','None','K only','PT Na only','DT Na only','Location','southeast')
ylabel('GFR (l/min)','Fontsize',24)
ti = get(gca,'TightInset');
ylim([0 0.17]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,0.95*yl(2),'B','Fontsize',28)

% Plasma K results
figure(3)
CK_data = [CK_m; CK_f];
% colormap(gray)
bar(CK_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'Male', 'Female'})
legend('All','None','K only','PT Na only','DT Na only','Location','southwest')
ylabel('Plasma [K^+] (mM)','Fontsize',24)
ti = get(gca,'TightInset');
% ylim([100 150]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,0.95*yl(2),'C','Fontsize',28)