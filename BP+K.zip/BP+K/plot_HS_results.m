% High salt results
% Cases: NTN, HTN (Combined, RSNA, RAAS, AA)
% Male, Female, M + F_RSAN, M + F_RAS, M + F_transport

% MAP results
map_ntn      = [105.7177  99.3354	105.3530  105.7730  100.7704];
map_htn_all  = [123.9251  116.2006  123.0298  123.8010  117.8291];
map_htn_rsna = [123.6700  112.3309  123.4721  123.5258  115.9837];
map_htn_ras  = [121.7875  110.5716  120.3330  121.7727  112.7489];
map_htn_aa   = [123.6067  116.6829  121.0603  123.4735	119.2148];

% M->F results
figure(1)
map_data = [map_ntn; map_htn_all; map_htn_rsna; map_htn_ras; map_htn_aa];
% colormap(gray)
bar(map_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined','RSNA','RAAS','AA'})
legend('Male, baseline HTN','Female','Male, F RSNA','Male, F RAAS','Male, F transport','Location','south')
ylabel('MAP (mmHg)','Fontsize',24)
ti = get(gca,'TightInset');
ylim([95 126]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,124.5,'A','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');


% GFR results
gfr_ntn      = [0.1368	0.1148	0.1367	0.1370	0.1198];
gfr_htn_all  = [0.1371	0.1146	0.1371	0.1370	0.1199];
gfr_htn_rsna = [0.1402	0.1164	0.1402	0.1400	0.1219];
gfr_htn_ras  = [0.1463	0.1200	0.1460	0.1462	0.1263];
gfr_htn_aa   = [0.1334	0.1128	0.1330	0.1331	0.1182];

% M->F results
figure(2)
gfr_data = [gfr_ntn; gfr_htn_all; gfr_htn_rsna; gfr_htn_ras; gfr_htn_aa];
% colormap(gray)
bar(gfr_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined', 'RSNA','RAAS','AA'})
legend('Male, baseline HTN','Female','Male, F RSNA','Male, F RAAS','Male, F transport','Location','southeast')
ylabel('GFR (l/min)','Fontsize',24)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
% ylim([100 135]);
yl = ylim;
text(0.6,0.95*yl(2),'B','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');

