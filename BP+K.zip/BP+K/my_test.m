% This script can be used for the "getSS" function

% clear 
clear all;

human = 1;
% gg = 1;  % male
gg = 2;  % female
sex = gg-1;
if sex == 0
    IG = 'Human_IG_Data/human_male_ss_0_0_0_rsna1.mat';
else
    IG = 'Human_IG_Data/human_female_ss_0_0_0_rsna1.mat';
end

% Parameters for diet type, blood pressure conditions, and GFR impairement
scale_Na_intake = 1.0; % multiples of normal Na intake
scale_K_intake  = 1.0;
htn_sim         = false;
htn_type        = 'All';  % only relevant if htn_sim = true
% htn_type        = 'RSNA';
% htn_type        = 'Renin';
% htn_type        = 'RAA';

% flags to set high K adaptations, only relevant if scale_K_intake > 1
% highKadapt = 'None';
% highKadapt = 'K only';
% highKadapt = 'PT only';
highKadapt = 'DT only';
% highKadapt = 'All';

% replace part of female model with male parameters
% to assess what drives sex differences in BP regulation
m_RSNA = false;
m_RAS  = false;
m_Reab = false;
% replace part of male model with female parameters
f_RSNA = false;
f_RAS  = false;
f_Reab = false;

% hypertension
if htn_sim
    switch htn_type
        case 'All'
            htn_rsna   = 1.3  ; % Multiplicative factor for RSNA to induce hypertension.
            htn_renin  = 1.3    ; % Multiplicative factor for Renin secretion to induce hypertension.
            htn_raa    = 1.5    ; % Multiplicative factor for baseline AA resistance to induce hypertension.
            htn_ald    = 1.0  ;
        case 'RSNA'
            htn_rsna   = 1.6  ; % Multiplicative factor for RSNA to induce hypertension.
            htn_renin  = 1.0    ; % Multiplicative factor for Renin secretion to induce hypertension.
            htn_raa    = 1.0  ; % Multiplicative factor for baseline AA resistance to induce hypertension.
            htn_ald    = 1.0  ;
        case 'Renin'
            htn_rsna   = 1.2  ; % Multiplicative factor for RSNA to induce hypertension.
            htn_renin  = 2.5    ; % Multiplicative factor for Renin secretion to induce hypertension.
            htn_raa    = 1.2  ; % Multiplicative factor for baseline AA resistance to induce hypertension.else
            htn_ald    = 2.5  ;
            % DT Na reabsorption is also increased, set below
        case 'RAA'
            htn_rsna   = 1.15  ; % Multiplicative factor for RSNA to induce hypertension.
            htn_renin  = 1.15  ; % Multiplicative factor for Renin secretion to induce hypertension.
            htn_raa    = 2.0  ; % Multiplicative factor for baseline AA resistance to induce hypertension.else
            htn_ald    = 1.0  ;
        otherwise
            display('Unknown HTN type')
    end
else  % normotension
    htn_rsna   = 1    ; % Multiplicative factor for RSNA to induce hypertension.
    htn_renin  = 1    ; % Multiplicative factor for Renin secretion to induce hypertension.
    htn_raa    = 1    ; % Multiplicative factor for baseline AA resistance to induce hypertension.
    htn_ald    = 1    ;
end
% 
scale_gfr  = 1.0    ; % <1 to similar low GFR, not really used

if scale_K_intake > 1.0 % high K diet
    switch highKadapt
        case 'None'
            if sex == 0  % male
                BP_PTreabsorb_param = [0.8 1.0 0.802];
                K_PTreabsorb_param  = [0 0.67];
            else  % female
                BP_PTreabsorb_param = [0.65 1.0 0.8];
                K_PTreabsorb_param  = [0 0.55];
           end
        case 'All'
            if sex == 0  % male
                BP_PTreabsorb_param = [0.72 0.9 0.74]; % male
                K_PTreabsorb_param  = [3 0.45];
            else
                BP_PTreabsorb_param = [0.65 0.6 0.73]; % female DT 0.75->0.5
                K_PTreabsorb_param  = [3 0.28];
            end
        case 'K only'
            if sex == 0  % male
                BP_PTreabsorb_param = [0.8 1.0 0.802];  % normal K diet values
                K_PTreabsorb_param  = [3 0.45];
            else  % female
                BP_PTreabsorb_param = [0.65 1.0 0.8];
                K_PTreabsorb_param  = [3 0.28];
            end
        case 'PT only'
            if sex == 0  % male
                BP_PTreabsorb_param = [0.72 1.0 0.74]; % male
                K_PTreabsorb_param  = [0 0.67];
            else
                BP_PTreabsorb_param = [0.65 1.0 0.78]; % female DT 0.75->0.5
                K_PTreabsorb_param  = [0 0.55];
            end
        case 'DT only'
            if sex == 0  % male
                BP_PTreabsorb_param = [0.8 0.9 0.74]; % male
                K_PTreabsorb_param  = [0 0.67];
            else
                BP_PTreabsorb_param = [0.65 0.6 0.73]; % female DT 0.75->0.5
                K_PTreabsorb_param  = [0 0.55];
            end
        otherwise
            display('Unknown K diet adaptaiton')
    end

else  % normal K diet
    if (sex == 0 && not(f_Reab)) || m_Reab % male
        BP_PTreabsorb_param = [0.8 1.0 0.802];
        K_PTreabsorb_param  = [0 0.67];
    else
        BP_PTreabsorb_param = [0.65 1.0 0.8];
        K_PTreabsorb_param  = [0 0.55];
    end
end

species = {'rat','human'};
gender     = {'male', 'female'};

%% Define default imputs for blood pressure model
AA = 1.5;
ACEi = 0;
furosemide = 0;
NSAID = 0;
myo_ind = 0;
water_ind = 0;
%% default inputs for K model
do_figs    = false;
do_insulin = true;
do_FF      = true;
MKX        = 0; MKXslope = 0;
alt_sim    = false; % use alternate equations

%% Drug Treatments
kappa_ACEi = 0;
kappa_f = 0;
kappa_f_md = 0;

if ACEi == 1
    kappa_ACEi = 0.76;
elseif ACEi > 1
    kappa_ACEi = 0.90;
end
if furosemide == 1
    kappa_f = 0.15;
    kappa_f_md = 0.4;
elseif furosemide ==2
    kappa_f = 0.3;
    kappa_f_md = 0.5;
end 


%% Parameters
% A small number of these parameters will be replaced by variables computed in the K model
%    this will be done in all_eqns, which calls the BP and K models
pars_BP = get_pars(species{human+1},gender{gg},'RSNA',htn_rsna,'R_aa',htn_raa,'Renin',htn_renin,'ALD',htn_ald,'low GFR',scale_gfr, ...
    'm_Reab',m_Reab,'m_RAS',m_RAS,'f_Reab',f_Reab,'f_RAS',f_RAS);

params_K = set_params(sex,scale_K_intake,m_Reab,f_Reab);
[pars_K, parnames] = pars2vector(params_K,0);

%% set initial conditions
% BP
SS_data_struct = load(IG,'SSdata');
SS_data_IG = SS_data_struct.SSdata;

if length(SS_data_IG) == 83
    SS_data_IG(84) = 0.126;  % water intake
end
x0_BP = SS_data_IG; t = 0;

% K
if sex == 0 % male
    temp = load('./SS/SS_5vars_male.mat');
elseif sex == 1 % female
    temp = load('./SS/SS_5vars_female.mat');
end
x0_K = temp.SS;

% ensure consistency
plasmaK = pars_BP(19);
V_b     = x0_BP(30);
total_K = V_b * plasmaK;
x0_K(2) = total_K;

% combine
x0 = [x0_BP x0_K];

%% Time-step model solution
tchange=0;
tspan = [0:500000];
% 
M = zeros(length(x0));
ind = [29 35 46 48 50 51 56 62 65 67 68 69 70 71 72 85:89];
for i=1:length(ind)
    M(ind(i),ind(i)) = 1; 
end
% now fill in extra entries
M(46,44) = -3/4;  % a_baro, a_auto
M(50,34) = -0.2;
%
options = odeset('Mass',M,'RelTol',1e-2,'AbsTol',1e-3*ones(1,length(x0)));
f = all_eqns(t,x0,pars_BP,pars_K,sex,tchange,...
                                        'ACEi',kappa_ACEi,'furosemide',[kappa_f,kappa_f_md],'NSAID',NSAID',...
                                        'Impaired Myogenic Response',myo_ind,'Low Water Intake',water_ind, ...
                                        'SS', true, 'alt_sim', alt_sim,...
                                        'do_MKX', [MKX, MKXslope],...
                                        'do_insulin', do_insulin,...
                                        'do_FF', do_FF,...
                                        'high K', BP_PTreabsorb_param, ...
                                        'TGF_eff', K_PTreabsorb_param, ...
                                        'm_RSNA', m_RSNA, 'f_RSNA',f_RSNA);
%
[t,x] = ode15s(@(t,x) all_eqns(t,x,pars_BP,pars_K,sex,tchange,...
                                        'ACEi',kappa_ACEi,'furosemide',[kappa_f,kappa_f_md],'NSAID',NSAID',...
                                        'Impaired Myogenic Response',myo_ind,'Low Water Intake',water_ind, ...
                                        'SS', true, 'alt_sim', alt_sim,...
                                        'do_MKX', [MKX, MKXslope],...
                                        'do_insulin', do_insulin,...
                                        'do_FF', do_FF,...
                                        'high K', BP_PTreabsorb_param,...
                                        'TGF_eff', K_PTreabsorb_param, ...
                                        'Na intake',scale_Na_intake, ...
                                        'm_RSNA', m_RSNA, 'f_RSNA',f_RSNA, 'f_Reab', f_Reab),...
                        tspan,x0, options);
y=x(end,:);

% %Check for imaginary solution.
if not (isreal(y))
    %disp('Imaginary number returned.')
    isimag = 1;
else
    isimag = 0;
end

% Set any values that are within machine precision of 0 equal to 0.
for i = 1:length(y)
    if abs(y(i)) < eps*100
        y(i) = 0;
    end
end

if false

display('final values')
fprintf('P_ma  %.4f\n',y(42))
fprintf('Phi_co %.4f\n',y(33))
% fprintf('P_mf %.4f\n',y(31))
% fprintf('P_ra %.4f\n',y(34))
fprintf('GFR   %.4f\n',y(7))
% fprintf('Phi_gh   %.4f\n',y(9))
fprintf('C_sod %.4f\n',y(52))
fprintf('C_K %.4f\n',y(86)/y(30))
fprintf('C_al  %.4f\n',y(55))
% fprintf('N_al  %.4f\n',y(56))
%% 
% fprintf('Phi_ptsodreab  %.4f\n',y(12))
% fprintf('Phi_dtsodreab  %.4f\n',y(18))
% fprintf('Phi_cdsodreab  %.4f\n',y(22))
% fprintf('Phi_mdsod  %.4f\n',y(17))
% fprintf('Sigma_tgf  %.4f\n',y(10))
fprintf('Phi_rb  %.4f\n',y(6))
% fprintf('R_aa  %.4f\n',y(73))
% fprintf('R_ea  %.4f\n',y(74))
% fprintf('R_a  %.4f\n',y(38))
% fprintf('R_ba  %.4f\n',y(39))
% fprintf('R_vr  %.4f\n',y(40))
% fprintf('R_tp  %.4f\n',y(41))
% fprintf('Sigma_TGF %.4f\n',y(10))
% fprintf('vas  %.4f\n',y(35))
%     fprintf('Phi_usod  %.4f\n',data(27))
%     fprintf('Phi_sodin  %.4f\n',data(28))
fprintf('C_adh %.4f\n',y(47))
% fprintf('RSNA %.4f\n',y(1))
% fprintf('eps_aum %.4f\n',y(43))
% fprintf('xi_ksod %.4f\n',y(58))
% fprintf('xi_map  %.4f\n',y(59))
% fprintf('xi_at   %.4f\n',y(60))
fprintf('U_sod %.4f\n',y(27))
fprintf('Urine %.6f\n',y(83))
% fprintf('Water intake  %.6f\n',y(84))
fprintf('V_ecf %.4f\n',y(29))
fprintf('V_b   %.4f\n\n',y(30))

display('average values')
fprintf('P_ma  %.4f\n', mean(x(:,42)))
fprintf('Phi_co %.4f\n', mean(x(:,33)))
% fprintf('P_mf %.4f\n',y(31))
% fprintf('P_ra %.4f\n',y(34))
fprintf('GFR   %.4f\n', mean(x(:,7)))
% fprintf('Phi_gh   %.4f\n',y(9))
fprintf('C_sod %.4f\n', mean(x(:,52)))
fprintf('C_K %.4f\n',mean(x(:,86)/mean(x(:,30))))
fprintf('C_al  %.4f\n', mean(x(:,55)))
% fprintf('N_al  %.4f\n',y(56))
%% 
% fprintf('Phi_ptsodreab  %.4f\n',y(12))
% fprintf('Phi_dtsodreab  %.4f\n',y(18))
% fprintf('Phi_cdsodreab  %.4f\n',y(22))
% fprintf('Phi_mdsod  %.4f\n',y(17))
% fprintf('Sigma_tgf  %.4f\n',y(10))
fprintf('Phi_rb  %.4f\n', mean(x(:,6)))
% fprintf('R_aa  %.4f\n',y(73))
% fprintf('R_ea  %.4f\n',y(74))
% fprintf('R_a  %.4f\n',y(38))
% fprintf('R_ba  %.4f\n',y(39))
% fprintf('R_vr  %.4f\n',y(40))
% fprintf('R_tp  %.4f\n',y(41))
% fprintf('Sigma_TGF %.4f\n',y(10))
% fprintf('vas  %.4f\n',y(35))
%     fprintf('Phi_usod  %.4f\n',data(27))
%     fprintf('Phi_sodin  %.4f\n',data(28))
fprintf('C_adh %.4f\n', mean(x(:,47)))
% fprintf('RSNA %.4f\n',y(1))
% fprintf('eps_aum %.4f\n',y(43))
% fprintf('xi_ksod %.4f\n',y(58))
% fprintf('xi_map  %.4f\n',y(59))
% fprintf('xi_at   %.4f\n',y(60))
fprintf('U_sod %.4f\n', mean(x(:,27)))
fprintf('Urine %.6f\n', mean(x(:,83)))
% fprintf('Water intake  %.6f\n',y(84))
fprintf('V_ecf %.4f\n', mean(x(:,29)))
fprintf('V_b   %.4f\n\n', mean(x(:,30)))

end
%%%%%%%%%%%%%

fprintf('P_ma  %.4f\n', mean(x(:,42)))
fprintf('Phi_co %.4f\n', mean(x(:,33)))
% fprintf('P_mf %.4f\n',y(31))
% fprintf('P_ra %.4f\n',y(34))
fprintf('GFR   %.4f\n', mean(x(:,7)))
% fprintf('Phi_gh   %.4f\n',y(9))
fprintf('M_sod %.4f\n', mean(x(:,51)))
fprintf('C_sod %.4f\n', mean(x(:,52)))
fprintf('C_K %.4f\n',mean(x(:,86)/mean(x(:,30))))
fprintf('C_al  %.4f\n', mean(x(:,55)))
% fprintf('N_al  %.4f\n',y(56))
%% 
fprintf('Phi_ptsodreab  %.4f\n',y(12))
fprintf('Phi_dtsodreab  %.4f\n',y(18))
fprintf('Phi_cdsodreab  %.4f\n',y(22))
fprintf('Phi_mdsod  %.4f\n',y(17))
fprintf('Sigma_tgf  %.4f\n',y(10))
fprintf('Psi_AT1RAA  %.4f\n',y(76))
fprintf('Psi_AT1REA  %.4f\n',y(77))
fprintf('Psi_AT2RAA  %.4f\n',y(78))
fprintf('Psi_AT2REA  %.4f\n',y(79))
fprintf('Phi_rb  %.4f\n', mean(x(:,6)))
fprintf('R_aa  %.4f\n',y(73))
fprintf('R_ea  %.4f\n',y(74))
fprintf('R_a  %.4f\n',y(38))
fprintf('R_ba  %.4f\n',y(39))
fprintf('R_vr  %.4f\n',y(40))
fprintf('R_tp  %.4f\n',y(41))
fprintf('vas  %.4f\n',y(35))
%     fprintf('Phi_sodin  %.4f\n',data(28))
fprintf('mu_Na  %.4f\n',y(82))
fprintf('C_adh %.4f\n', mean(x(:,47)))
fprintf('RSNA %.4f\n',y(1))
fprintf('eps_aum %.4f\n',y(43))
fprintf('xi_ksod %.4f\n',y(58))
fprintf('xi_map  %.4f\n',y(59))
fprintf('xi_at   %.4f\n',y(60))
fprintf('U_sod %.4f\n', mean(x(:,27)))
fprintf('Urine %.6f\n', y(83)) %mean(x(:,83)))
fprintf('Water intake  %.6f\n',y(84))
fprintf('V_ecf %.4f\n', mean(x(:,29)))
fprintf('V_b   %.4f\n\n', mean(x(:,30)))

plot_profile (t,x)

% save_name_ending = '';
% if water_ind
%     save_name_ending = strcat(save_name_ending,'_lowwaterintake');
% end
% if myo_ind
%     save_name_ending = strcat(save_name_ending,'_impairedmyo');
% end

% save_data_name = sprintf('%s_%s_ss_%s_%s_%s_rsna%s%s.mat', species{human+1},gender{gg},num2str(ACEi),num2str(furosemide),num2str(NSAID),num2str(AA),save_name_ending);
% save_data_name = strcat('Human_Data/', save_data_name);
% save(save_data_name, 'SSdata', 'residual', 'exitflag', 'output'