function f = all_eqns(t,x,pars_BP,pars_K,sex,tchange,varargin)

    num_BP_var = 84;  % number of variables in BP model
    x_BP = x(1:num_BP_var);
    x_K  = x(num_BP_var+1:end);

    % set plasma [K] in pars_BP
    total_K = x(num_BP_var+2);
    V_b     = x(30);
    plasmaK = total_K/V_b;
    pars_BP(19) = plasmaK;

    f_BP = bp_eqns(t,x_BP,pars_BP,tchange,varargin{:});

    % set plasma [Na], [ALD], DT reabsorption, and GFR in pars_K
    pars_K(28) = x(52);  % Csod
    pars_K(32) = x(55);  % C_al
    pars_K(33) = x(18);  % Phi_dtsodreab
    pars_K(15) = x(7);   % GFR_base
    pars_K(6)  = x(30);   % V plasma
    pars_K(7)  = x(29);   % V interstitial
    f_K  = kreg_eqns(t,x_K,sex,pars_K,varargin{:});

    f = [f_BP; f_K];

end