% Hypertensive results
% Triggers: Combined, RSNA, RAAS, AA
% Male, Female, M + F_RSAN, M + F_RAS, M + F_transport

% MAP results
map_all  = [120.2570  114.8111  119.9130  120.1354  115.7082];
map_rsna = [119.5111  110.1034  118.7911  119.3589  113.3718];
map_ras  = [119.3089  109.1461  118.3681  119.2899  110.3544];
map_aa   = [119.9805  115.5983  118.4217  119.8559  117.1505];

% M->F results
figure(1)
map_data = [map_all; map_rsna; map_ras; map_aa];
% colormap(gray)
bar(map_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'Combined', 'RSNA','RAAS','AA'})
legend('Male, baseline HTN','Female','Male, F RSNA','Male, F RAAS','Male, F transport','Location','southwest')
ylabel('MAP (mmHg)','Fontsize',24)
ti = get(gca,'TightInset');
ylim([100 125]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,123.5,'A','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');


% GFR results
gfr_all  = [0.1319  0.1066  0.1318	0.1316	0.1088];
gfr_rsna = [0.1349	0.1081	0.1347	0.1347	0.1111];
gfr_ras  = [0.1429	0.1134	0.1427	0.1428	0.1175];
gfr_aa   = [0.1271	0.1049	0.1268	0.1268	0.1073];

% M->F results
figure(2)
gfr_data = [gfr_all; gfr_rsna; gfr_ras; gfr_aa];
% colormap(gray)
bar(gfr_data)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'Combined', 'RSNA','RAAS','AA'})
legend('Male, baseline HTN','Female','Male, F RSNA','Male, F RAAS','Male, F transport','Location','southeast')
ylabel('GFR (l/min)','Fontsize',24)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
% ylim([100 135]);
yl = ylim;
text(0.6,0.95*yl(2),'B','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');

