function plot_profile (t, x)

%% Retrieve variables by name.

rsna          = x(:,1 ); 
alpha_map     = x(:,2 ); 
alpha_rap     = x(:,3 ); 
R_r           = x(:,4 ); 
beta_rsna     = x(:,5 ); 
Phi_rb        = x(:,6 ); 
Phi_gfilt     = x(:,7 ); 
P_f           = x(:,8 ); 
P_gh          = x(:,9 ); 
Sigma_tgf     = x(:,10); 
Phi_filsod    = x(:,11); 
Phi_ptsodreab = x(:,12); 
eta_ptsodreab = x(:,13); 
gamma_filsod  = x(:,14); 
gamma_at      = x(:,15); 
gamma_rsna    = x(:,16); 
Phi_mdsod     = x(:,17); 
Phi_dtsodreab = x(:,18); 
eta_dtsodreab = x(:,19); 
psi_al        = x(:,20); 
Phi_dtsod     = x(:,21); 
Phi_cdsodreab = x(:,22); 
eta_cdsodreab = x(:,23); 
lambda_dt     = x(:,24); 
lambda_anp    = x(:,25); 
lambda_al     = x(:,26); 
Phi_usod      = x(:,27); 
Phi_sodin     = x(:,28); 
V_ecf         = x(:,29); 
V_b           = x(:,30); 
P_mf          = x(:,31); 
Phi_vr        = x(:,32); 
Phi_co        = x(:,33); 
P_ra          = x(:,34); 
vas           = x(:,35); 
vas_f         = x(:,36); 
vas_d         = x(:,37); 
R_a           = x(:,38); 
R_ba          = x(:,39); 
R_vr          = x(:,40); 
R_tp          = x(:,41); 
P_ma          = x(:,42); 
epsilon_aum   = x(:,43); 
a_auto        = x(:,44); 
a_chemo       = x(:,45); 
a_baro        = x(:,46); 
C_adh         = x(:,47);  
N_adh         = x(:,48);  
N_adhs        = x(:,49); 
delta_ra      = x(:,50); 
M_sod         = x(:,51); 
C_sod         = x(:,52); 
nu_mdsod      = x(:,53); 
nu_rsna       = x(:,54); 
C_al          = x(:,55); 
N_al          = x(:,56);  
N_als         = x(:,57); 
xi_ksod       = x(:,58); 
xi_map        = x(:,59); 
xi_at         = x(:,60); 
hatC_anp      = x(:,61); 
AGT           = x(:,62); 
nu_AT1        = x(:,63); 
R_sec         = x(:,64); 
PRC           = x(:,65); 
PRA           = x(:,66); 
AngI          = x(:,67); 
AngII         = x(:,68); 
AT1R          = x(:,69); 
AT2R          = x(:,70); 
Ang17         = x(:,71); 
AngIV         = x(:,72); 
R_aa          = x(:,73); 
R_ea          = x(:,74); 
Sigma_myo     = x(:,75); 
Psi_AT1RAA    = x(:,76); 
Psi_AT1REA    = x(:,77); 
Psi_AT2RAA    = x(:,78); 
Psi_AT2REA    = x(:,79); 
Phi_twreab    = x(:,80); 
mu_adh        = x(:,81); 
mu_Na         = x(:,82); 
Phi_u         = x(:,83); 
Phi_win       = x(:,84); 
M_Kgut        = x(:,85); % amount of K in gut
M_Kplas       = x(:,86); % amount of K in plasma
M_Kinter      = x(:,87); % amount of K in interstitial space
M_Kmuscle     = x(:,88); % amount of K in muscle
N_al          = x(:,89); % normalized ALD

figure(1)
subplot(3,3,1)
plot(t,P_ma), title('P_{ma}')
subplot(3,3,2)
plot(t,P_ra), title('P_{ra}')
subplot(3,3,3)
plot(t,M_Kplas), title('total plasma K')
subplot(3,3,4)
plot(t,C_sod), title('plasma [Na]')
subplot(3,3,5)
plot(t,M_Kplas./V_b), title('plasma [K]')
subplot(3,3,6)
plot(t,Phi_u), title('urine output')
subplot(3,3,7)
plot(t,Phi_gfilt), title('GFR')
subplot(3,3,8)
plot(t,Phi_usod), title('E_{Na}')
