% High Na / High K results
% Cases: NTN, HTN (Combined, RSNA, RAAS, AA)
% NS/NK, HS/NK, NS/HK, HS/HK; M and F
close all

% MAP results
map_ntn_m      = [102.3561	105.7177    94.7807	96.0209];
map_htn_all_m  = [120.2226	123.9251	111.7583	112.9563];
map_htn_rsna_m = [119.5260	123.6700	108.5228	10.0249];
map_htn_ras_m  = [119.3171	121.7875	106.6143	107.5962];
map_htn_aa_m   = [119.9055	123.6067	113.1805	114.3919];

map_ntn_f      = [97.7377	99.3354	    92.2272	92.9860];
map_htn_all_f  = [114.5875	116.2006	109.8654	110.5195];
map_htn_rsna_f = [109.7946	112.3309	102.2257	103.2810];
map_htn_ras_f  = [108.4308	110.2047	103.7280	104.4804];
map_htn_aa_f   = [115.4110	116.6829	111.4933	112.0344];

% M HS/HK results
figure(1)
map_data_m = [map_ntn_m; map_htn_all_m; map_htn_rsna_m; map_htn_ras_m; map_htn_aa_m];
% colormap(gray)
bar(map_data_m)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined','RSNA','RAAS','AA'})
legend('NS/NK','HS/NK','NS/HK','HS/HK','Location','southeast')
ylabel('MAP (mmHg)','Fontsize',24)
ti = get(gca,'TightInset');
ylim([50 135]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,0.95*yl(2),'A1: Male','Fontsize',28)


% M HS/HK results
figure(2)
map_data_f = [map_ntn_f; map_htn_all_f; map_htn_rsna_f; map_htn_ras_f; map_htn_aa_f];
% colormap(gray)
bar(map_data_f)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined','RSNA','RAAS','AA'})
legend('NS/NK','HS/NK','NS/HK','HS/HK','Location','southeast')
ylabel('MAP (mmHg)','Fontsize',24)
ti = get(gca,'TightInset');
ylim([50 135]);
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
yl = ylim;
text(0.6,0.95*yl(2),'A2: Female','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');


% GFR results
gfr_ntn_m      = [0.1305	0.1368	0.0936	0.0986];
gfr_htn_all_m  = [0.1318	0.1372	0.0941	0.0987];
gfr_htn_rsna_m = [0.1349	0.1402	0.0967	0.1012];
gfr_htn_ras_m  = [0.1429	0.1463	0.1022	0.1061];
gfr_htn_aa_m   = [0.1270	0.1334	0.0909	0.0959];

gfr_ntn_f      = [0.1057	0.1148	0.0693	0.0737];
gfr_htn_all_f  = [0.1051	0.1146	0.0695	0.0738];
gfr_htn_rsna_f = [0.1068	0.1164	0.0703	0.0746];
gfr_htn_ras_f  = [0.1100	0.1190	0.0741	0.0797];
gfr_htn_aa_f   = [0.1033	0.1128	0.0674	0.0717];

% GFR results
figure(3)
gfr_data_m = [gfr_ntn_m; gfr_htn_all_m; gfr_htn_rsna_m; gfr_htn_ras_m; gfr_htn_aa_m];
% colormap(gray)
bar(gfr_data_m)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined', 'RSNA','RAAS','AA'})
legend('NS/NK','HS/NK','NS/HK','HS/HK','Location','southeast')
ylabel('GFR (l/min)','Fontsize',24)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
ylim([0 0.15]);
yl = ylim;
text(0.6,0.95*yl(2),'B1: Male','Fontsize',28)

% GFR results
figure(4)
gfr_data_f = [gfr_ntn_f; gfr_htn_all_f; gfr_htn_rsna_f; gfr_htn_ras_f; gfr_htn_aa_f];
% colormap(gray)
bar(gfr_data_f)
set(gca,'Fontsize',22)
set(gca,'XTickLabel',{'NTN', 'Combined', 'RSNA','RAAS','AA'})
legend('NS/NK','HS/NK','NS/HK','HS/HK','Location','southeast')
ylabel('GFR (l/min)','Fontsize',24)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);
ylim([0 0.15]);
yl = ylim;
text(0.6,0.95*yl(2),'B2: Female','Fontsize',28)

% create inset
% hold on
% % axes('position',[0.52 0.5 0.45 0.35]);
% axes('position',[0.65 0.5 0.25 0.35]);
% % bar([1 2.4 3.8 5.2],Naflowall(:,4:end)')
% bar(Na_data(:,end-1:end)')
% set(gca,'Fontsize',20)
% set(gca,'XTickLabel',{'CCD','urine'})
% print('rat_Na_deliv.png','-dpng');

